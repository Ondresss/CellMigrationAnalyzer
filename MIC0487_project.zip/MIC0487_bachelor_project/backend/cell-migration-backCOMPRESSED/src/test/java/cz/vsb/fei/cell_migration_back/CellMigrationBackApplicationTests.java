package cz.vsb.fei.cell_migration_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CellMigrationBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
