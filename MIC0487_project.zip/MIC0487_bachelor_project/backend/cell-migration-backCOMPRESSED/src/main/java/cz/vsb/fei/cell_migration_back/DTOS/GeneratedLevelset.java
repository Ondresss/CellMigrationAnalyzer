package cz.vsb.fei.cell_migration_back.DTOS;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GeneratedLevelset {

	private String file;
	private String fileName;
	
	
}
